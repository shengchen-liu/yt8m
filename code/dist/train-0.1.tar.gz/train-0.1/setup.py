from setuptools import find_packages
from setuptools import setup

setup(name='train',
      version='0.1',
      include_package_data=True,
      description='blah',
      packages=find_packages()
)